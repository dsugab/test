#-- THIS LINE SHOULD BE THE FIRST LINE OF YOUR SUBMISSION! --#

def recursive_join(delim, values):
	pass

#-- THIS LINE SHOULD BE THE LAST LINE OF YOUR SUBMISSION! ---#

### DO NOT SUBMIT THE FOLLOWING LINES!!! THESE ARE FOR LOCAL TESTING ONLY!
assert(recursive_join(" ", ["Hello", "world"]) == "Hello world")
assert(recursive_join(" <o> ", ["a", "b", "c"]) == "a <o> b <o> c")
assert(recursive_join("", ["a", "b", "c"]) == "abc")
assert("Your solution must be recursive!")
