#-- THIS LINE SHOULD BE THE FIRST LINE OF YOUR SUBMISSION! --#

def find_both_ways(text, word):
	pass

#-- THIS LINE SHOULD BE THE LAST LINE OF YOUR SUBMISSION! ---#

### DO NOT SUBMIT THE FOLLOWING LINES!!! THESE ARE FOR LOCAL TESTING ONLY!
assert(find_both_ways("Hello, World!", "lo, wo") == (True, 1))
assert(find_both_ways("Hello, God!", "Dog") == (True, -1))
assert(find_both_ways("Hello, California!", "local") == (False, 0))

