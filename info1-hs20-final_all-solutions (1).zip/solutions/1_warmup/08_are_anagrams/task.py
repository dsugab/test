#-- THIS LINE SHOULD BE THE FIRST LINE OF YOUR SUBMISSION! --#

def are_anagrams(a, b):
	pass

#-- THIS LINE SHOULD BE THE LAST LINE OF YOUR SUBMISSION! ---#

### DO NOT SUBMIT THE FOLLOWING LINES!!! THESE ARE FOR LOCAL TESTING ONLY!
assert(are_anagrams('Dog', 'God'))
assert(are_anagrams("The Meaning of Life.", "The fine game of nil!"))
assert(not are_anagrams("The Meaning of Life", "Work"))

